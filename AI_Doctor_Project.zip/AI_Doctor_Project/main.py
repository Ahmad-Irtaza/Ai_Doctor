import sys
import tkinter as tk
from tkinter import ttk
from app.styles import apply_styles

from app.interface import SymptomInterface
from app.utils import load_symptom_list

# Append AI engine path
sys.path.append('ai_engine')
from ai_engine import inference

TRAINING_FILE = 'datasets/disease_symptoms_training.csv'

def load_symptom_index():
    symptoms = load_symptom_list(TRAINING_FILE)
    return {symptom: idx for idx, symptom in enumerate(symptoms)}

def on_symptom_submit(selected_symptoms):
    symptom_index = load_symptom_index()
    vector = [0] * len(symptom_index)

    for symptom in selected_symptoms:
        if symptom in symptom_index:
            vector[symptom_index[symptom]] = 1

    predictions = inference.get_disease_prediction(vector, training_file=TRAINING_FILE)

    hybrid_disease = predictions['Hybrid Prediction']
    hybrid_meds, hybrid_precs = inference.get_recommendations(hybrid_disease)

    result_text = f"""
🔍 A* Prediction: {predictions['A* Prediction']}
💊 Medicines: {inference.get_recommendations(predictions['A* Prediction'])[0]}
🛡️ Precautions: {inference.get_recommendations(predictions['A* Prediction'])[1]}

📊 Naive Bayes Prediction: {predictions['Naive Bayes Prediction']}
💊 Medicines: {inference.get_recommendations(predictions['Naive Bayes Prediction'])[0]}
🛡️ Precautions: {inference.get_recommendations(predictions['Naive Bayes Prediction'])[1]}

⚡ Hybrid Prediction: {hybrid_disease}
💊 Medicines: {hybrid_meds}
🛡️ Precautions: {hybrid_precs}
"""

    result_window = tk.Toplevel()
    result_window.title("Prediction Result")
    result_window.configure(bg="#1e1e2f")
    result_window.geometry("800x400")

    text_area = tk.Text(result_window, wrap='word', bg="#1e1e2f", fg="white", font=("Courier New", 12), bd=0)
    text_area.insert("1.0", result_text)
    text_area.config(state='disabled')
    text_area.pack(expand=True, fill="both", padx=10, pady=10)

    scrollbar = ttk.Scrollbar(result_window, command=text_area.yview)
    text_area.config(yscrollcommand=scrollbar.set)
    scrollbar.pack(side="right", fill="y")

if __name__ == "__main__":
    root = tk.Tk()
    root.title("AI Doctor - Smart Symptom Checker")
    root.geometry("1200x800")

    apply_styles(root)

    app = SymptomInterface(master=root, on_submit_callback=on_symptom_submit)
    app.pack(fill="both", expand=True, padx=10, pady=10)

    root.mainloop()
