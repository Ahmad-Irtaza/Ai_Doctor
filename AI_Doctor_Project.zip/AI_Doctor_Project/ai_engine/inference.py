import csv
from ai_engine.naive_bayes import NaiveBayesClassifier
from ai_engine.search_algorithms import a_star_search
import math
# Load medicines recommendations from CSV
def load_medicines_recommendations(file_path='datasets/medicines.csv'):
    medicines = {}
    with open(file_path, 'r') as file:
        reader = csv.reader(file)
        for row in reader:
            disease = row[0]
            medicines[disease] = row[1:]
    return medicines

# Load precautions recommendations from CSV
def load_precautions_recommendations(file_path='datasets/precautions.csv'):
    precautions = {}
    with open(file_path, 'r') as file:
        reader = csv.reader(file)
        for row in reader:
            disease = row[0]
            precautions[disease] = row[1:]
    return precautions

# Function to get disease prediction using A*, Naive Bayes, and Hybrid approach
def get_disease_prediction(input_vector, training_file='datasets/disease_symptoms_training.csv'):
    # A* Prediction
    a_star_disease, a_star_score = a_star_search(input_vector, training_file)

    # Naive Bayes Prediction
    naive_bayes_classifier = load_and_train_naive_bayes(training_file)
    naive_bayes_disease = predict_using_naive_bayes(naive_bayes_classifier, input_vector)

    # Hybrid Prediction (currently using Naive Bayes logic — replace with actual hybrid logic if available)
    hybrid_disease = hybrid_disease_prediction(input_vector, naive_bayes_classifier)

    return {
        'A* Prediction': a_star_disease,
        'A* Score': a_star_score,
        'Naive Bayes Prediction': naive_bayes_disease,
        'Hybrid Prediction': hybrid_disease
    }

# Function to get medicines and precautions recommendations for a disease
def get_recommendations(disease):
    medicines_data = load_medicines_recommendations()
    precautions_data = load_precautions_recommendations()

    medicines = medicines_data.get(disease, ['Consult a doctor for proper medication.'])
    precautions = precautions_data.get(disease, ['Stay safe and follow medical advice.'])

    return ', '.join(medicines), ', '.join(precautions)

# Helper function to load and train Naive Bayes classifier
def load_and_train_naive_bayes(training_file='datasets/disease_symptoms_training.csv'):
    naive_bayes_classifier = NaiveBayesClassifier()
    naive_bayes_classifier.train(training_file)
    return naive_bayes_classifier

# Helper function to predict using Naive Bayes classifier
def predict_using_naive_bayes(naive_bayes_classifier, input_vector):
    return naive_bayes_classifier.predict(input_vector)

# Placeholder for hybrid logic – currently same as naive bayes, can be replaced with custom logic
def hybrid_disease_prediction(input_vector, naive_bayes_classifier, training_file='datasets/disease_symptoms_training.csv'):
    # Step 1: Get A* result
    a_star_disease, a_star_score = a_star_search(input_vector, training_file)

    # Step 2: Get Naive Bayes result and log probability
    scores = {}
    for disease in naive_bayes_classifier.disease_labels:
        log_prob = math.log(naive_bayes_classifier.class_probs[disease])
        for i in range(naive_bayes_classifier.symptom_count):
            prob = naive_bayes_classifier.symptom_probs[disease][i]
            if input_vector[i] == 1:
                log_prob += math.log(prob)
            else:
                log_prob += math.log(1 - prob)
        scores[disease] = log_prob
    naive_bayes_disease = max(scores, key=scores.get)
    nb_log_score = scores[naive_bayes_disease]

    # Step 3: Combine logic
    if a_star_disease == naive_bayes_disease:
        return naive_bayes_disease  # If both predictions agree, return the common disease
    else:
        # Step 4: Choose based on confidence
        if nb_log_score > -3:  # You can fine-tune this threshold based on your observations
            return naive_bayes_disease  # If Naive Bayes has higher confidence (log probability), return it
        else:
            return a_star_disease  # Otherwise, return the A* predicted disease
