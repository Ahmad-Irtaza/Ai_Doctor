from naive_bayes import NaiveBayesClassifier

# Instantiate classifier
classifier = NaiveBayesClassifier()

# Train using your dataset
classifier.train('datasets/test_training.csv') # Adjust path if needed

# Simulate a user input vector (must be 300-length, matching symptoms count)
# Example: First 3 symptoms active (1), rest 0


# test_input = [1, 1, 1] + [0] * (classifier.symptom_count - 3)



test_input = [1,0,0,0,0] 


# Predict
prediction = classifier.predict(test_input)

print("Predicted Disease:", prediction)
