# test_search.py

from inference import get_disease_prediction, hybrid_disease_prediction

# Create a sample symptom vector (length must be 258)
test_vector = [0] * 258
test_vector[2] = 1
test_vector[10] = 1
test_vector[25] = 1
test_vector[77] = 1

# Run comparison between A* and Naive Bayes
results = get_disease_prediction(test_vector)

print(f"A* Prediction: {results['A* Prediction']}")
print(f"A* Score (Euclidean Distance): {results['A* Score']}\n")

print(f"Naive Bayes Prediction: {results['Naive Bayes Prediction']}\n")

if results['A* Prediction'] == results['Naive Bayes Prediction']:
    print("✅ Both algorithms agree on the disease prediction!")
else:
    print(f"⚠️ Disagreement: A* → {results['A* Prediction']}, Naive Bayes → {results['Naive Bayes Prediction']}")

# Hybrid approach
hybrid_prediction = hybrid_disease_prediction(test_vector)
print(f"\n🧠 Hybrid Prediction: {hybrid_prediction}")
