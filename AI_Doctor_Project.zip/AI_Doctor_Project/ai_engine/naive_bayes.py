import csv
import math
from collections import defaultdict

class NaiveBayesClassifier:
    def __init__(self):
        self.symptom_probs = {}  # symptom_probs[disease][symptom_index] = P(symptom|disease)
        self.class_probs = {}    # P(disease)
        self.symptom_count = 0
        self.disease_labels = []

    def train(self, filepath):
        disease_count = defaultdict(int)
        symptom_sum_by_disease = defaultdict(lambda: [0] * self.symptom_count)
        total_records = 0

        # First pass to get symptom count
        with open(filepath, 'r') as file:
            reader = csv.reader(file)
            header = next(reader)
            self.symptom_count = len(header) - 1  # exclude label
            # reinit with actual count
            symptom_sum_by_disease = defaultdict(lambda: [0] * self.symptom_count)

        # Second pass for training
        with open(filepath, 'r') as file:
            reader = csv.reader(file)
            next(reader)  # skip header

            for row in reader:
                symptoms = list(map(int, row[:-1]))
                disease = row[-1]
                disease_count[disease] += 1
                for i in range(self.symptom_count):
                    symptom_sum_by_disease[disease][i] += symptoms[i]
                total_records += 1

        # Calculate class probabilities
        self.class_probs = {
            disease: disease_count[disease] / total_records
            for disease in disease_count
        }

        # Calculate conditional probabilities P(symptom_i|disease)
        self.symptom_probs = {}
        for disease, symptom_sums in symptom_sum_by_disease.items():
            total = disease_count[disease]
            self.symptom_probs[disease] = [
                (symptom_count + 1) / (total + 2)  # Laplace smoothing
                for symptom_count in symptom_sums
            ]
        self.disease_labels = list(disease_count.keys())

    def predict(self, input_vector):
        scores = {}
        for disease in self.disease_labels:
            log_prob = math.log(self.class_probs[disease])
            for i in range(self.symptom_count):
                prob = self.symptom_probs[disease][i]
                if input_vector[i] == 1:
                    log_prob += math.log(prob)
                else:
                    log_prob += math.log(1 - prob)
            scores[disease] = log_prob
        return max(scores, key=scores.get)
