# ai_engine/search_algorithms.py

import csv
import numpy as np
import heapq

def load_training_data(file_path):
    """
    This function loads the training data from a CSV file, extracting diseases, symptom vectors, 
    and the list of symptoms.
    
    :param file_path: Path to the training CSV file
    :return: Tuple containing diseases, vectors, and symptoms list
    """
    diseases = []
    vectors = []
    symptoms_list = []  # Initialize an empty list to hold symptom data

    with open(file_path, newline='') as csvfile:
        reader = csv.reader(csvfile)
        next(reader)  # Skip header row in CSV file
        for row in reader:
            # Extract the symptom vector (binary) from the row and the disease label
            symptoms = row[:-1]  # All columns except the last one are symptoms
            vectors.append([int(x) for x in symptoms])  # Convert symptom data to integers (0 or 1)
            diseases.append(row[-1])  # The last column is the disease name
            symptoms_list.append(symptoms)  # Append the symptoms to the symptoms list

    return diseases, vectors, symptoms_list  # Return the diseases, symptom vectors, and symptoms list


def heuristic(test_vector, disease_vector):
    """
    Heuristic function to calculate the distance between the test symptoms and the disease symptoms.
    We use Euclidean distance as the heuristic function.
    
    :param test_vector: Test symptom vector from the user
    :param disease_vector: Symptom vector of the disease in the database
    :return: Euclidean distance between the two vectors
    """
    return np.linalg.norm(np.array(test_vector) - np.array(disease_vector))


def a_star_search(symptom_vector, training_file='datasets/disease_symptoms_training.csv'):
    """
    A* search algorithm to find the disease with the closest match to the test symptom vector.
    
    The A* algorithm combines both the cost to reach a state (the distance between the test vector and disease symptoms)
    and a heuristic (similarity between the symptoms).
    
    :param symptom_vector: A list of symptoms from the user to be diagnosed
    :param training_file: Path to the training dataset file (default is 'datasets/disease_symptoms_training.csv')
    :return: Predicted disease and the heuristic score (distance)
    """
    # Load training data: diseases, vectors, and symptoms list
    diseases, vectors, _ = load_training_data(training_file)
    
    # Initialize variables to track the best match (lowest distance)
    best_disease = None
    best_score = float('inf')  # Set the initial score to a very high value (inf)

    # Priority queue for A* search - we are using the Euclidean distance as the heuristic
    open_list = []  # List to track open states for A*
    heapq.heappush(open_list, (0, symptom_vector))  # Push the starting state with a cost of 0
    
    # Loop through each disease in the dataset to compute the "cost" of reaching that disease
    for i, disease_vector in enumerate(vectors):
        disease = diseases[i]
        
        # Compute the heuristic (Euclidean distance) between the test vector and the disease vector
        score = heuristic(symptom_vector, disease_vector)
        
        # If the current disease is a better match (lower score), update the best disease
        if score < best_score:
            best_score = score
            best_disease = disease

    # Return the predicted disease and the score (distance) for the match
    return best_disease, best_score


def hamming_distance(vec1, vec2):
    """
    Calculate Hamming distance between two binary vectors. 
    Hamming distance measures the number of differing elements between two vectors.
    
    :param vec1: The first binary vector
    :param vec2: The second binary vector
    :return: Hamming distance (number of differing positions)
    """
    return sum(x != y for x, y in zip(vec1, vec2))
