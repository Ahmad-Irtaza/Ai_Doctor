# test_search.py
from naive_bayes import NaiveBayesClassifier
from search_algorithms import a_star_search
import math
# Example binary symptom vector (with 258 symptoms, adjust as needed)
test_vector = [0] * 258  # Initialize a vector of 258 elements, all set to 0
test_vector[2] = 1       # Example: set some symptoms as present (1)
test_vector[10] = 1      # Example: set more symptoms as present
test_vector[25] = 1
test_vector[77] = 1

# Initialize Naive Bayes classifier and load training data (ensure you have a valid file path)
naive_bayes = NaiveBayesClassifier()
naive_bayes.train('datasets/disease_symptoms_training.csv')  # Adjust with your actual file path

# Get predictions from both algorithms
a_star_disease, a_star_score = a_star_search(test_vector)
naive_bayes_disease = naive_bayes.predict(test_vector)

# Print A* prediction and comparison
print(f"A* Prediction: {a_star_disease}")
print(f"A* Score (Euclidean Distance): {a_star_score}\n")

# For Naive Bayes, print the predicted disease and its log probability
# Naive Bayes' 'predict' method does not directly give log probabilities, so we will compute log probability
# for the predicted disease manually based on the training data
log_probabilities = {disease: math.log(prob) for disease, prob in naive_bayes.class_probs.items()}
print(f"Naive Bayes Prediction: {naive_bayes_disease}")
print(f"Naive Bayes Log Probability for {naive_bayes_disease}: {log_probabilities.get(naive_bayes_disease, 'Not Available')}")

# Compare if both algorithms agree on the same prediction
if a_star_disease == naive_bayes_disease:
    print("Both algorithms agree on the disease prediction!")
else:
    print(f"Disagreement: A* predicted {a_star_disease}, but Naive Bayes predicted {naive_bayes_disease}.")
