# utils.py
import pandas as pd

def load_symptom_list(training_file):
    df = pd.read_csv(training_file)
    symptom_list = list(df.columns[:-1])  # Exclude the 'Disease' column
    return symptom_list
