# test_import.py
import sys
import os

# Add the root project directory to sys.path
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

# Debugging output
print(f"sys.path: {sys.path}")
print("Current working directory:", os.getcwd())

# Check if naive_bayes.py exists in the ai_engine directory
naive_bayes_path = os.path.join(os.getcwd(), 'ai_engine', 'naive_bayes.py')
if os.path.exists(naive_bayes_path):
    print(f"naive_bayes.py found at: {naive_bayes_path}")
else:
    print(f"naive_bayes.py NOT found at: {naive_bayes_path}")

# Attempting to import from ai_engine
try:
    import ai_engine.inference
    print("ai_engine module imported successfully")
except ModuleNotFoundError as e:
    print(f"Import Error: {e}")
