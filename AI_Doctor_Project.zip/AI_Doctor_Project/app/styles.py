# styles.py
import tkinter as tk
from tkinter import ttk
import os

# Color scheme
BACKGROUND_COLOR = '#1e1e2f'         # Dark Navy
PRIMARY_TEXT_COLOR = '#ffffff'       # White
ACCENT_COLOR = '#4fd1c5'             # Teal
WARNING_COLOR = '#f56565'            # Soft Red
LISTBOX_BG = '#2b2b3c'               # Slightly lighter for Listboxes
LISTBOX_FG = '#e6e6e6'
HIGHLIGHT_BG = '#4fd1c5'

# Font styles (defined inside apply_styles)
def apply_styles(root):
    # Load the Azure theme
    theme_path = os.path.join("app", "themes", "Azure-ttk-theme-main", "azure.tcl")
    try:
        root.tk.call("source", theme_path)
        root.tk.call("set_theme", "dark")  # Only "dark" or "light"
    except tk.TclError:
        print("Warning: Azure theme already loaded or error with theme loading.")
    
    style = ttk.Style(root)

    # General UI font is removed here as we are using font directly in widgets now
    # Global background
    style.configure("TFrame", background=BACKGROUND_COLOR)
    style.configure("TLabel", background=BACKGROUND_COLOR, foreground=PRIMARY_TEXT_COLOR)
    style.configure("TButton", padding=6)
    style.map("TButton", foreground=[("active", "#ffffff")], background=[("active", ACCENT_COLOR)])

    style.configure("TEntry", padding=5)
    style.configure("TCombobox", padding=5)
    style.configure("TLabelframe", background=BACKGROUND_COLOR, foreground=PRIMARY_TEXT_COLOR, font=('Segoe UI', 11, 'bold'))
    style.configure("TLabelframe.Label", background=BACKGROUND_COLOR, foreground=ACCENT_COLOR)

    # Add hover effects for buttons
    style.map("TButton", background=[('active', ACCENT_COLOR), ('hover', '#3f929e')])

    # Scrollbar (optional styling if used)
    style.configure("Vertical.TScrollbar", gripcount=0, background=ACCENT_COLOR,
                    darkcolor=ACCENT_COLOR, lightcolor=ACCENT_COLOR, troughcolor=BACKGROUND_COLOR)

    # Improve focus visibility
    style.map("TCombobox",
              fieldbackground=[('readonly', BACKGROUND_COLOR)],
              background=[('readonly', BACKGROUND_COLOR)],
              foreground=[('readonly', PRIMARY_TEXT_COLOR)])

    # Ensure consistency in popups or Toplevels (can be reused in main.py)
    root.configure(bg=BACKGROUND_COLOR)
