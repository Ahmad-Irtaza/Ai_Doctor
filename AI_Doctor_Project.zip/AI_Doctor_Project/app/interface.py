import tkinter as tk
from tkinter import ttk, messagebox
import tkinter.font as tkFont
import csv
from app.styles import apply_styles

SYMPTOM_CSV = 'datasets/symptom_categories.csv'

class SymptomInterface(tk.Frame):
    def __init__(self, master=None, on_submit_callback=None, **kwargs):
        super().__init__(master, **kwargs)
        self.master = master
        self.on_submit_callback = on_submit_callback
        self.symptom_data = self.load_symptom_data()
        self.selected_symptoms = []
        self.active_category = None
        self.default_font = tkFont.Font(family="Segoe UI", size=11)  # Corrected font format
        self.build_ui()

    def load_symptom_data(self):
        data = {}
        with open(SYMPTOM_CSV, newline='') as f:
            reader = csv.DictReader(f)
            for row in reader:
                cat = row['category']
                sym = row['symptom']
                data.setdefault(cat, []).append(sym)
        return data

    def build_ui(self):
        self.pack(fill='both', expand=True)
        apply_styles(self.master)

        cat_frame = tk.Frame(self)
        cat_frame.pack(pady=5)
        tk.Label(cat_frame, text="Select Category:", fg='white', bg='#1e1e2f', font=self.default_font).pack(side='left', padx=5)  # Corrected font format
        self.cat_var = tk.StringVar()
        cat_options = list(self.symptom_data.keys())
        self.cat_dropdown = ttk.Combobox(cat_frame, textvariable=self.cat_var, values=cat_options, state='readonly', style='TCombobox')
        self.cat_dropdown.pack(side='left')
        self.cat_dropdown.bind('<<ComboboxSelected>>', self.filter_category)

        search_frame = tk.Frame(self)
        search_frame.pack(pady=5)
        tk.Label(search_frame, text="Search Symptom:", fg='white', bg='#1e1e2f', font=self.default_font).pack(side='left')  # Corrected font format
        self.search_var = tk.StringVar()
        self.search_entry = ttk.Entry(search_frame, textvariable=self.search_var, width=40, style='TEntry')
        self.search_entry.pack(side='left', padx=5)
        self.search_entry.bind('<KeyRelease>', self.update_autocomplete)
        self.search_entry.bind('<Return>', self.select_first_autocomplete)

        self.suggestion_box = tk.Listbox(self, height=5, selectmode='single', exportselection=False, activestyle='none', bg='#34495e', fg='white', font=self.default_font)
        self.suggestion_box.pack(fill='x', padx=20)
        self.suggestion_box.bind("<<ListboxSelect>>", self.add_selected_symptom)

        self.symptoms_frame = ttk.LabelFrame(self, text="Symptoms", labelanchor='n', style="TLabelframe")
        self.symptoms_frame.pack(fill='x', padx=10, pady=10)
        self.symptom_listbox = tk.Listbox(self.symptoms_frame, height=8, exportselection=False, bg='#34495e', fg='white', font=self.default_font)
        self.symptom_listbox.pack(fill='x', padx=10, pady=5)
        self.symptom_listbox.bind("<<ListboxSelect>>", self.add_selected_symptom)

        sel_frame = ttk.LabelFrame(self, text="Selected Symptoms", labelanchor='n', style="TLabelframe")
        sel_frame.pack(fill='x', padx=10, pady=10)
        self.selected_list = tk.Frame(sel_frame)
        self.selected_list.pack(fill='x')

        self.predict_btn = ttk.Button(self, text="🩺 Predict Disease", command=self.trigger_prediction, style="TButton")
        self.predict_btn.pack(pady=10)

    def filter_category(self, event=None):
        self.symptom_listbox.delete(0, 'end')
        selected = self.cat_var.get()
        self.active_category = selected
        if selected in self.symptom_data:
            for sym in sorted(self.symptom_data[selected]):
                self.symptom_listbox.insert('end', sym)
        self.update_autocomplete()

    def update_autocomplete(self, event=None):
        text = self.search_var.get().lower()
        self.suggestion_box.delete(0, 'end')
        source = self.symptom_data.get(self.active_category, []) if self.active_category else sum(self.symptom_data.values(), [])
        for symptom in source:
            if text in symptom.lower():
                self.suggestion_box.insert('end', symptom)

    def select_first_autocomplete(self, event=None):
        if self.suggestion_box.size() > 0:
            self.suggestion_box.selection_set(0)
            self.add_selected_symptom_from_box(self.suggestion_box)

    def add_selected_symptom(self, event):
        self.add_selected_symptom_from_box(event.widget)

    def add_selected_symptom_from_box(self, widget):
        try:
            selection = widget.get(widget.curselection())
        except:
            return
        if selection not in self.selected_symptoms:
            self.selected_symptoms.append(selection)
            self.refresh_selected_list()

    def refresh_selected_list(self):
        for widget in self.selected_list.winfo_children():
            widget.destroy()
        for symptom in self.selected_symptoms:
            row = tk.Frame(self.selected_list)
            row.pack(anchor='w')
            tk.Label(row, text=symptom, fg='white', font=self.default_font).pack(side='left')
            del_btn = ttk.Button(row, text='❌', command=lambda s=symptom: self.remove_symptom(s), style="TButton")
            del_btn.pack(side='left')

    def remove_symptom(self, symptom):
        self.selected_symptoms.remove(symptom)
        self.refresh_selected_list()

    def trigger_prediction(self):
        if not self.selected_symptoms:
            messagebox.showwarning("No Symptoms Selected", "Please select at least one symptom.")
            return
        self.on_submit_callback(self.selected_symptoms)
