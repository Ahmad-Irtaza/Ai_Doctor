import random
import csv
import os

# Ensure the datasets directory exists
os.makedirs("datasets", exist_ok=True)

# Disease list (can be extended further)
diseases = [
    "Flu", "Common Cold", "COVID-19", "Migraine", "Strep Throat", "Food Poisoning", "Heart Disease",
    "Stomach Infection", "Anemia", "Pneumonia", "Tuberculosis", "Malaria", "Cancer", "Diabetes",
    "Asthma", "Kidney Disease", "Liver Disease", "Hepatitis A", "Hepatitis B", "Stroke", "Hypertension",
    "Arthritis", "Leukemia", "Parkinson's Disease", "Alzheimer's Disease", "Urinary Tract Infection",
    "GERD", "Rheumatoid Arthritis", "Epilepsy", "Crohn's Disease", "Multiple Sclerosis", "Appendicitis",
    "Gallbladder Disease", "Thyroid Disorder", "Celiac Disease", "Lupus", "Psoriasis", "Eczema",
    "Tonsillitis", "Sinusitis", "Bronchitis", "Dengue", "Typhoid", "Cholera", "Meningitis", "Whooping Cough",
    "Scarlet Fever", "Polio", "Zika Virus", "Yellow Fever", "Measles", "Mumps", "Rubella", "Chickenpox",
    "Shingles", "Ringworm", "Scabies", "Lyme Disease", "Tetanus", "Rabies", "Gonorrhea", "Syphilis",
    "HIV/AIDS", "Chlamydia", "Trichomoniasis", "Herpes", "Mononucleosis", "Pancreatitis", "Osteoporosis",
    "Fibromyalgia", "Sickle Cell Anemia", "Hemophilia", "Cystic Fibrosis", "Obesity", "Insomnia",
    "Sleep Apnea", "Restless Leg Syndrome", "Narcolepsy", "Depression", "Anxiety", "Bipolar Disorder",
    "Schizophrenia", "PTSD", "Obsessive-Compulsive Disorder", "ADHD", "Autism Spectrum Disorder", 
    "Dyslexia", "Conduct Disorder", "Bulimia", "Anorexia", "Alcoholism", "Drug Addiction", 
    "Glaucoma", "Cataract", "Macular Degeneration", "Conjunctivitis", "Dry Eye Syndrome", "Otitis Media",
    "Tinnitus", "Hearing Loss", "Vertigo", "Bell’s Palsy", "Trigeminal Neuralgia", "ALS",
    "Spinal Cord Injury", "Carpal Tunnel Syndrome", "Sciatica", "Gout", "Bursitis", "Plantar Fasciitis",
    "Tendonitis", "ACL Injury", "Bone Fracture", "Osteoarthritis", "Skin Cancer", "Lung Cancer",
    "Colon Cancer", "Breast Cancer", "Prostate Cancer", "Oral Cancer", "Esophageal Cancer", 
    "Pancreatic Cancer", "Throat Cancer", "Laryngeal Cancer", "Bladder Cancer", "Testicular Cancer",
    "Cervical Cancer", "Ovarian Cancer", "Endometriosis", "Polycystic Ovary Syndrome", "Infertility",
    "Menstrual Disorders", "Menopause", "Prostatitis", "Erectile Dysfunction", "Premature Ejaculation",
    "Benign Prostatic Hyperplasia", "Gallstones", "Kidney Stones", "Acid Reflux", "Constipation",
    "Irritable Bowel Syndrome", "Ulcerative Colitis", "Diverticulitis", "Gastritis", "Peptic Ulcer",
    "Hiatal Hernia", "Lactose Intolerance", "Food Allergies", "Shellfish Allergy", "Peanut Allergy",
    "Dust Allergy", "Pollen Allergy", "Pet Allergy", "Astigmatism", "Myopia", "Hyperopia",
    "Color Blindness", "Amblyopia", "Motion Sickness", "Jet Lag", "Altitude Sickness",
    "Dehydration", "Hypothermia", "Heat Stroke", "Sunburn", "Burns", "Frostbite", "Snake Bite",
    "Bee Sting", "Insect Bite Allergy", "Lead Poisoning", "Mercury Poisoning", "Carbon Monoxide Poisoning",
    "Radiation Sickness", "Anaphylaxis", "Sepsis", "Laryngitis", "Pharyngitis", "Encephalitis",
    "Myocarditis", "Pericarditis", "Endocarditis", "Aneurysm", "Varicose Veins", "Deep Vein Thrombosis",
    "Pulmonary Embolism", "Sarcoidosis", "Sjogren’s Syndrome", "Raynaud's Disease", "Cushing’s Syndrome",
    "Addison’s Disease", "Graves’ Disease", "Hashimoto’s Thyroiditis", "Wilson’s Disease", 
    "Gilbert’s Syndrome", "Marfan Syndrome", "Turner Syndrome", "Klinefelter Syndrome", 
    "Tourette Syndrome", "Reye’s Syndrome", "Kawasaki Disease", "Hand-Foot-and-Mouth Disease",
    "Impetigo", "Boils", "Cellulitis", "Warts", "Lichen Planus"
]

# Expanded medicine pool
medicine_pool = [
    "Paracetamol", "Ibuprofen", "Aspirin", "Amoxicillin", "Azithromycin", "Cetirizine", 
    "Diphenhydramine", "Prednisone", "Metformin", "Lisinopril", "Losartan", "Simvastatin", 
    "Albuterol", "Salbutamol", "Hydrocodone", "Furosemide", "Warfarin", "Methotrexate", 
    "Loratadine", "Fluoxetine", "Sertraline", "Gabapentin", "Lisinopril", "Atenolol", 
    "Hydroxychloroquine", "Fentanyl", "Diazepam", "Clonazepam", "Methylprednisolone", 
    "Ranitidine", "Omeprazole", "Famotidine", "Ciprofloxacin", "Levofloxacin", "Doxycycline", 
    "Hydrochlorothiazide", "Acetaminophen", "Ketorolac", "Tizanidine", "Dexamethasone", 
    "Levothyroxine", "Clarithromycin", "Erythromycin", "Penicillin", "Sildenafil", "Metronidazole", 
    "Budesonide", "Loratadine", "Insulin", "Ramipril", "Baclofen", "Mirtazapine", "Lamotrigine", 
    "Valproic Acid", "Topiramate", "Pregabalin", "Zolpidem", "Diphenhydramine", "Fexofenadine", 
    "Cetirizine", "Propranolol", "Duloxetine", "Citalopram", "Escitalopram", "Fluconazole", 
    "Clindamycin", "Bacitracin", "Nitrofurantoin", "Hydroxyurea", "Sodium Bicarbonate", 
    "Calcium Carbonate", "Tamsulosin", "Sitagliptin", "Gliclazide", "Metoclopramide", 
    "Colchicine", "Chloroquine", "Meclizine", "Prochlorperazine", "Diphenhydramine", 
    "Cefuroxime", "Cefixime", "Sulfamethoxazole", "Trimethoprim", "Fosfomycin", "Nitroglycerin", 
    "Morphine", "Hydromorphone", "Oxycodone", "Piroxicam", "Meloxicam", "Celecoxib", 
    "Tramadol", "Methadone", "Naproxen", "Tadalafil", "Pregabalin", "Brimonidine", "Timolol", 
    "Methotrexate", "Allopurinol", "Lidocaine", "Benadryl", "Mupirocin", "Benzoyl Peroxide", 
    "Finasteride", "Rifampin", "Tetracycline", "Acetazolamide", "Phenytoin", "Valganciclovir", 
    "Loperamide", "Zinc Oxide", "Lisinopril", "Cimetidine", "Dextromethorphan", "Chlorpheniramine", 
    "Clonidine", "Adalimumab", "Duloxetine", "Azathioprine", "Tacrolimus", "Eculizumab", 
    "Filgrastim", "Rituximab", "Cyclophosphamide", "Methotrexate", "Imuran", "Etanercept", 
    "Amlodipine", "Nifedipine", "Ramipril", "Clonazepam", "Lorazepam", "Flurazepam", 
    "Temazepam", "Buspirone", "Varenicline", "Zolpidem", "Topiramate", "Sumatriptan", 
    "Eletriptan", "Frovatriptan", "Rizatriptan", "Ergotamine", "Dihydroergotamine", 
    "Ranitidine", "Tizanidine", "Nabilone", "Marinol", "Zaleplon", "Melatonin", "Cyclobenzaprine", 
    "Carbamazepine", "Oxcarbazepine", "Topiramate", "Etoricoxib", "Indomethacin", "Diclofenac", 
    "Zonisamide", "Donepezil", "Rivastigmine", "Galantamine", "Memantine", "Sildenafil", 
    "Tadalafil", "Vardenafil", "Tamsulosin", "Finasteride", "Dutasteride", "Fluticasone", 
    "Budesonide", "Beclometasone", "Salmeterol", "Formoterol", "Ipratropium", "Tiotropium", 
    "Fluticasone Salmeterol", "Montelukast", "Cromolyn", "Theophylline", "Levalbuterol", 
    "Albuterol", "Mometasone", "Triamcinolone", "Hydrocortisone", "Prednisolone", 
    "Dexamethasone", "Betamethasone", "Budesonide", "Flunisolide", "Methacholine", 
    "Salmeterol", "Formoterol", "Advair", "Symbicort", "Singulair", "Chantix", 
    "Nicotine patches", "Nicotine gum", "Bupropion", "Varenicline", "Duloxetine", 
    "Desvenlafaxine", "Paroxetine", "Sertraline", "Citalopram", "Escitalopram", "Fluoxetine", 
    "Bupropion", "Trazodone", "Mirtazapine", "Amitriptyline", "Imipramine", "Nortriptyline", 
    "Phenelzine", "Tranylcypromine", "Isocarboxazid", "Selegiline", "Loxapine", "Olanzapine"

]

# Create and write to CSV
with open('datasets/disease_medicines.csv', 'w', newline='') as file:
    writer = csv.DictWriter(file, fieldnames=["Disease", "Medicines"])
    writer.writeheader()

    for _ in range(1000):  # Generate 1000 entries
        disease = random.choice(diseases)
        meds = random.sample(medicine_pool, random.randint(1, 3))  # 1-3 medicines
        writer.writerow({
            "Disease": disease,
            "Medicines": ", ".join(meds)
        })

print("✅ 'disease_medicines.csv' generated successfully.")
