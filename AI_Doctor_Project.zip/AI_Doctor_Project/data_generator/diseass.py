import random
import csv

# Use the expanded symptoms list from previous message
symptoms = [
    "Fever", "Cough", "Fatigue", "Headache", "Sore Throat", "Nausea", 
    "Shortness of Breath", "Chills", "Chest Pain", "Diarrhea", "Dizziness", 
    "Body Aches", "Loss of Taste or Smell", "Runny Nose", "Vomiting", 
    "Rash", "Joint Pain", "Abdominal Pain", "Sweating", "Constipation", 
    "Insomnia", "Blood in Stool", "Severe Cough", "Coughing up Blood", 
    "Excessive Thirst", "Weight Loss", "Difficulty Swallowing", "Itchy Skin", 
    "Unexplained Bleeding", "Confusion", "Memory Loss", "Tiredness", 
    "Night Sweats", "Swelling", "Skin Rash", "Loss of Appetite", 
    "Increased Heart Rate", "Tremors", "Seizures", "Itchy Eyes", 
    "Hearing Loss", "Blurred Vision", "Painful Urination", "Dark Urine", 
    "Pale Skin", "Skin Peeling", "Lethargy", "Muscle Weakness", 
    "Difficulty Breathing", "Persistent Cough", "Abnormal Heartbeat", 
    "Persistent Sneezing", "Sore Muscles", "Dry Mouth", "Increased Hunger", 
    "Frequent Urination", "Excessive Hunger", "Swollen Lymph Nodes", 
    "Loss of Coordination", "Weight Gain", "Increased Thirst", "Fainting", 
    "Cold Sweats", "Vomiting Blood", "Belly Bloating", "Painful Joints", 
    "Swollen Ankles", "Vomiting Food", "Dry Skin", "Pale Complexion", 
    "Numbness", "Fatigue after Exercise", "Eye Irritation", "Sore Eyes", 
    "Irregular Menstrual Cycle", "Dehydration", "Loss of Consciousness", 
    "Memory Loss", "Leg Swelling", "Bloodshot Eyes", "Tinnitus", 
    "Excessive Coughing at Night", "Swollen Feet", "Painful Swallowing", 
    "Skin Redness", "Frequent Throat Clearing", "Sensitivity to Light", 
    "Loss of Balance", "Muscle Cramps", "Shortness of Breath after Exercise", 
    "Weakness in Arms or Legs", "Dry Eyes", "Unusual Moles or Spots", 
    "Pale Lips", "Choking Sensation", "Flushing", "Mouth Ulcers", 
    "Nosebleeds", "Sore Gums", "Black or Tarry Stools", "Sensitivity to Cold", 
    "Painful Skin", "Bleeding Gums", "Loss of Voice", "Hiccups", 
    "Severe Abdominal Pain", "Yellowing of Skin or Eyes", "Hot Flashes", 
    "Feeling of Fullness", "Numbness in Hands or Feet", "Poor Appetite", 
    "Muscle Tension", "Decreased Libido", "Increased Sleepiness", 
    "Excessive Urination at Night", "Persistent Hiccups", "Unexplained Weight Loss", 
    "Severe Chest Pressure", "Unexplained Back Pain", "Difficulty Speaking", 
    "Vision Problems", "Sensitivity to Touch", "Uncontrollable Shaking", 
    "Pins and Needles Sensation", "Difficulty Moving Arms or Legs", 
    "Heartburn", "Difficulty Walking", "Chronic Fatigue", "Nausea After Eating", 
    "Sudden Mood Changes", "Chronic Coughing", "Sudden Weakness", 
    "Pale or Yellow Tongue", "Painful Breathing", "Swollen Abdomen", "Head Tilt", 
    "Difficulty Concentrating", "Blurred Vision", "Dry Throat", "Chronic Back Pain", 
    "Muscle Stiffness", "Cramps", "Swollen Lymph Nodes", "Heavy Breathing", 
    "Pounding Heart", "Sore Teeth", "Itchy Nose", "Skin Bruising", "Low Blood Pressure", 
    "Swollen Glands", "Cold Hands", "Cold Feet", "Pain in Legs", "Drowsiness", 
    "Increased Salivation", "Neck Pain", "Slight Fever", "Mild Headache", 
    "Frequent Urination at Night", "Pain during Exercise", "Trouble Sleeping", 
    "Stomach Cramps", "Faint Heartbeat", "Gastric Bloating", "Loss of Taste", 
    "Loss of Smell", "Blurry Eyes", "Dry Cough", "Eye Strain", "Drowsy Feeling", 
    "Pain in Chest", "Throbbing Headache", "Mental Fog", "Confusion", "Sore Throat", 
    "Persistent Thirst", "Hoarseness", "Coughing", "Severe Fatigue", "Difficult Breathing",
    "Restlessness", "Increased Sweating", "Dizziness upon Standing", "Head Pressure", 
    "Dry Lips", "Inflamed Gums", "Feeling Cold", "Hunger Pangs", "Abnormal Skin Color",
    "Painful Abdominal Area", "Aching Body", "Neck Stiffness", "Gag Reflex", "Shivering", 
    "Discomfort during Eating", "Stomach Upset", "Tiredness after Work", "Sensation of Pressure", 
    "Flu-like Symptoms", "Headaches After Eating", "Insomnia After Eating", "Sudden Heart Palpitations", 
    "Reduced Appetite", "Dry Skin", "Nausea without Vomiting", "Fainting", "Frequent Thirst",
    "Hyperactivity", "Feeling Swollen", "Lack of Energy", "Stiff Joints", "Cold Sweats",
    "Frequent Burping", "Stomach Gurgling", "Nervousness", "Lack of Coordination", 
    "Increased Respiratory Rate", "Difficulty Walking", "Dizziness upon Standing", "Jaundice",
    "Joint Swelling", "Bloating", "Tightness in Chest", "Irritable Mood", "Tingling Sensation",
    "Tired Eyes", "Excessive Yawning", "Feeling of Floating", "Unstable Walking", 
    "Cold Shivers", "Painful Swallowing", "Heaviness in Chest", "Feeling Out of Breath",
    "Tingling in Hands", "Dry Cough at Night", "Pain When Urinating", "Reduced Senses", 
    "Numbness in Arms", "Cold Body", "Hard to Breathe", "Abnormal Joint Movements", 
    "Soreness in Jaw", "Lack of Focus", "Painful Stomach", "Tingling in Feet", 
    "Rapid Heart Rate", "Excessive Drooling", "Rash on Skin", "Pain Behind Eyes", 
    "Unusual Sweating", "Spasms in Muscles", "Thick Mucus", "Persistent Nausea", 
    "Coughing at Night", "Irritable Bowels", "Fatigue after Eating", "Pale Skin", "Bloody Mucus"
]

# Disease pool
diseases = [
    "Flu", "Common Cold", "COVID-19", "Migraine", "Strep Throat", "Food Poisoning", "Heart Disease",
    "Stomach Infection", "Anemia", "Pneumonia", "Tuberculosis", "Malaria", "Cancer", "Diabetes",
    "Asthma", "Kidney Disease", "Liver Disease", "Hepatitis A", "Hepatitis B", "Stroke", "Hypertension",
    "Arthritis", "Leukemia", "Parkinson's Disease", "Alzheimer's Disease", "Urinary Tract Infection",
    "GERD", "Rheumatoid Arthritis", "Epilepsy", "Crohn's Disease", "Multiple Sclerosis", "Appendicitis",
    "Gallbladder Disease", "Thyroid Disorder", "Celiac Disease", "Lupus", "Psoriasis", "Eczema",
    "Tonsillitis", "Sinusitis", "Bronchitis", "Dengue", "Typhoid", "Cholera", "Meningitis", "Whooping Cough",
    "Scarlet Fever", "Polio", "Zika Virus", "Yellow Fever", "Measles", "Mumps", "Rubella", "Chickenpox",
    "Shingles", "Ringworm", "Scabies", "Lyme Disease", "Tetanus", "Rabies", "Gonorrhea", "Syphilis",
    "HIV/AIDS", "Chlamydia", "Trichomoniasis", "Herpes", "Mononucleosis", "Pancreatitis", "Osteoporosis",
    "Fibromyalgia", "Sickle Cell Anemia", "Hemophilia", "Cystic Fibrosis", "Obesity", "Insomnia",
    "Sleep Apnea", "Restless Leg Syndrome", "Narcolepsy", "Depression", "Anxiety", "Bipolar Disorder",
    "Schizophrenia", "PTSD", "Obsessive-Compulsive Disorder", "ADHD", "Autism Spectrum Disorder", 
    "Dyslexia", "Conduct Disorder", "Bulimia", "Anorexia", "Alcoholism", "Drug Addiction", 
    "Glaucoma", "Cataract", "Macular Degeneration", "Conjunctivitis", "Dry Eye Syndrome", "Otitis Media",
    "Tinnitus", "Hearing Loss", "Vertigo", "Bell’s Palsy", "Trigeminal Neuralgia", "ALS",
    "Spinal Cord Injury", "Carpal Tunnel Syndrome", "Sciatica", "Gout", "Bursitis", "Plantar Fasciitis",
    "Tendonitis", "ACL Injury", "Bone Fracture", "Osteoarthritis", "Skin Cancer", "Lung Cancer",
    "Colon Cancer", "Breast Cancer", "Prostate Cancer", "Oral Cancer", "Esophageal Cancer", 
    "Pancreatic Cancer", "Throat Cancer", "Laryngeal Cancer", "Bladder Cancer", "Testicular Cancer",
    "Cervical Cancer", "Ovarian Cancer", "Endometriosis", "Polycystic Ovary Syndrome", "Infertility",
    "Menstrual Disorders", "Menopause", "Prostatitis", "Erectile Dysfunction", "Premature Ejaculation",
    "Benign Prostatic Hyperplasia", "Gallstones", "Kidney Stones", "Acid Reflux", "Constipation",
    "Irritable Bowel Syndrome", "Ulcerative Colitis", "Diverticulitis", "Gastritis", "Peptic Ulcer",
    "Hiatal Hernia", "Lactose Intolerance", "Food Allergies", "Shellfish Allergy", "Peanut Allergy",
    "Dust Allergy", "Pollen Allergy", "Pet Allergy", "Astigmatism", "Myopia", "Hyperopia",
    "Color Blindness", "Amblyopia", "Motion Sickness", "Jet Lag", "Altitude Sickness",
    "Dehydration", "Hypothermia", "Heat Stroke", "Sunburn", "Burns", "Frostbite", "Snake Bite",
    "Bee Sting", "Insect Bite Allergy", "Lead Poisoning", "Mercury Poisoning", "Carbon Monoxide Poisoning",
    "Radiation Sickness", "Anaphylaxis", "Sepsis", "Laryngitis", "Pharyngitis", "Encephalitis",
    "Myocarditis", "Pericarditis", "Endocarditis", "Aneurysm", "Varicose Veins", "Deep Vein Thrombosis",
    "Pulmonary Embolism", "Sarcoidosis", "Sjogren’s Syndrome", "Raynaud's Disease", "Cushing’s Syndrome",
    "Addison’s Disease", "Graves’ Disease", "Hashimoto’s Thyroiditis", "Wilson’s Disease", 
    "Gilbert’s Syndrome", "Marfan Syndrome", "Turner Syndrome", "Klinefelter Syndrome", 
    "Tourette Syndrome", "Reye’s Syndrome", "Kawasaki Disease", "Hand-Foot-and-Mouth Disease",
    "Impetigo", "Boils", "Cellulitis", "Warts", "Lichen Planus"
]


# Create dataset with 1000+ entries
with open('datasets/disease_symptoms.csv', 'w', newline='') as csvfile:
    fieldnames = ['Disease', 'Symptoms']
    writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
    writer.writeheader()

    for _ in range(1000):  # create 1000 rows
        disease = random.choice(diseases)
        num_symptoms = random.randint(3, 7)
        selected_symptoms = random.sample(symptoms, num_symptoms)
        writer.writerow({
            'Disease': disease,
            'Symptoms': ", ".join(selected_symptoms)
        })

print("✅ Generated 1000+ entries in 'disease_symptoms.csv'.")
